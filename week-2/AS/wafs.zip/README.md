# Single-page web app

Tijdens de derde week van de Minor Everything Web.

Hierbij maak ik gebruik van de API, van http://cannabisreports.com, deze API bevat data over de
verschillende Cannabis Strains en de stamboom van de desbetreffende soort.

 
Ik maak gebruik van de volgende Micro Libraries: 

- underscore.js ---> Mapping
- aja.js        ---> Ajax Calls
- routie.js     ---> Router
- transparancy.js ---> Templating engine

Het resultaat is te zien op: https://goo.gl/5wvk5P

#### Wishlist: 

- Pagination
- Sorting, alphabetic



 